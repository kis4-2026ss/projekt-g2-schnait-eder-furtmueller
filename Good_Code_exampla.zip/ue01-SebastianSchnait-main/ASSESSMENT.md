# **Übung 1 - Erfüllungsgrad**

Nachname und Vorname: Schnait Sebastian

Aufwand [Stunden]:    21.0

## **Erfüllungsgrad**

| Beispiel  | Gewichtung  | Lösungsidee (15%) | Implement. (70%) | Testen (15%) |
| --------- | :---------: |:-----------------:|:----------------:|:------------:|
| 1.1       | 30          |        100        |       100        |     100      |
| 1.2       | 35          |        100        |       100        |     100      |
| 1.3       | 20          |        100        |       100        |     100      |
| 1.4       | 10          |        100        |       100        |     100      |
| 1.5       |  5          |        100        |       100        |     100      |
