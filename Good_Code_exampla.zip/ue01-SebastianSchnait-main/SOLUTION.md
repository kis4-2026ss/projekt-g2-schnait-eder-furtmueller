# **Übung 1- Ausarbeitung**

## **Diskrete Ereignissimulation **


### **1.1**
#### **Lösungsidee**
Die Lösungsidee war die abstrakte Klasse Event, von der sich alle zukünftigen Eventtypen ableiten,
zu implementieren. In dieser Klasse werden getTime() und compareTo() implementiert, was von allen
abgeleteten Klassen geerbt wird.
Zusätzlich wird noch die Klasse Simulation implementiert, die mehrere Events in einer PriorityQueue
speichert und entweder mit run() oder step() abarbeiten kann.

#### **Testfälle**
In SimulationTest:

<img src="Images/SimulationTest.png" alt="Image_SimulationTest">


### **1.2**
#### **Lösungsidee**
Die Lösungsidee war, die von Event abgeleiteten Klassen CustomerArrivalEvent, CustomerAbandonEvent 
und ServiceEndEvent zu entwickeln. Der Zeitverlauf wird dadurch simuliert, dass sich diese Events
gegenseitig aufrufen und die Simulation Zeit um die jeweils entsprechende Zeit erhöht wird. 
Diese Zeit wird in der von Simulation abgeleiteten Klasse Supermarktet berechnet.
Zusätzlich werden noch die Klassen Customer, Checkout und SimulationParameters implementiert.
In der Klasse SupermarketClient kann das ganze Programm, mit gewünschten Werten, ausgeführt werden.
#### **Testfälle**

In CheckoutTest:

<img src="Images/CheckoutTest.png" alt="Image_CheckoutTest">

In CustomerTest:

<img src="Images/CustomerTest.png" alt="Image_CustomerTest">

In CustomerArrivalEventTest:

<img src="Images/CustomerArrivalEventTest.png" alt="Image_CustomerArrivalEventTest">

In CustomerAbandonEventTest:

<img src="Images/CustomerAbandonEventTest.png" alt="Image_CustomerAbandonEventTest">

In ServiceEndEventTest:

<img src="Images/ServiceEndEventTest.png" alt="Image_ServiceEndEventTest">


In SupermarketTest:

<img src="Images/SupermarketTest.png" alt="Image_SupermarketTest">

Test von SupermarketClient:

<img src="Images/SupermarketClient.png" alt="Image_SupermarketClientTest" width="500">




### **1.3.**
#### **Lösungsidee**
Die Lösungsidee war, die Klasse SupermarketStats zu entwickeln in der die dementsprechenden 
Berechnungen durchgeführt werden. 
Zusätzlich wird die von Supermaket abgeleitete Klasse SupermarketStatistic entwickelt, 
die die benötigten Werte von den einzelnen Events an SupermarketStats weitergiebt.
Die Einzelnen Events werden um die benötigten Funktionsaufrufe erweitert, abhängig davon ob
die Simulation mit der gearbeitet wird vom Typ SupermarketStatistic, und nicht nur Supermarket
ist.
In der Klasse SupermarketClientStatistic kann das ganze Programm, mit gewünschten Werten, ausgeführt werden.

#### **Testfälle**

In SupermarketStatsTest:

<img src="Images/SupermarketStatsTest.png" alt="Image_SupermarketStatsTest">

In SupermarketStatisticTest:

<img src="Images/SupermarketStatisticTest.png" alt="Image_SupermarketStatisticTest">

Test von SupermarketStatisticClient:

<img src="Images/SupermarketStatisticClient.png" alt="Image_SupermarketStatisticClient" width="500">

Test von SupermarketStatisticClient (Volle Auslastung):

<img src="Images/SupermarketStatisticClient2.png" alt="Image_SupermarketStatisticClient2" width="500">

Test von SupermarketStatisticClient (Kaum Auslastung):

<img src="Images/SupermarketStatisticClient3.png" alt="Image_SupermarketStatisticClient3" width="500">




### **1.4.**
#### **Lösungsidee**
Die Lösungsidee war, das Interface ArrivalProfile, mit der abgeleiteten Klasse PeriosicArrivalProfile
zu entwickeln. Darin werden die einzelnen Ankunftsraten in einem double-Array gespeichert und basierend
auf der aktuellen Simulationszeit ausgegeben. Ist eine der Ankunftsraten <= 0, wird so lange weitergesprungen
bis eine positive Ankunftsrate erreicht wird oder die Simulation zu ende ist.
Zusätzlich wird die von SupermarketStatistic abgeleitete Klasse ProfiledSupermarketStatistic erstellt
die die Funktion nextInterarrivalTime() überschreibt.
Um Fehler zu vermeiden, da die Simulation immer mit einem CustomerArrivalEvent gestartet wird, muss
die erste Ankunfstrate positiv sein. Dadurch werden auch Fehler vermieden falls 
nur eine Ankunfstrate, die <= 0 ist eingegeben wird.
In der Klasse ProfiledSupermarketClientStatistic kann das ganze Programm, mit gewünschten Werten, ausgeführt werden.

#### **Testfälle**
In PeriodicArrivalProfileTest:

<img src="Images/PeriodicArrivalProfileTest.png" alt="Image_PeriodicArrivalProfileTest">

In ProfiledSupermarketStatisticTest:

<img src="Images/ProfiledSupermarketStatisticTest.png" alt="Image_ProfiledSupermarketStatisticTest">

Test von ProfiledSupermarketStatisticClient (zweite Periodenhälfte geschlossen):

<img src="Images/ProfiledSupermarketStatisticClient.png" alt="Image_ProfiledSupermarketStatisticClient" width="500">

Test von ProfiledSupermarketStatisticClient (Mitten in Periode geschlossen):

<img src="Images/ProfiledSupermarketStatisticClient2.png" alt="Image_ProfiledSupermarketStatisticClient2" width="500">

Test von ProfiledSupermarketStatisticClient (Stark schwankend während Periode):

<img src="Images/ProfiledSupermarketStatisticClient3.png" alt="Image_ProfiledSupermarketStatisticClient3" width="500">

### **1.5.**
#### **Lösungsidee**
Die Lösungsidee war, die gegebenen Werte in der Klasse ProfiledSupermarketClientStatistic
einzugeben und mit verschiedener Anzahl an Checkouts zu überprüfen wie die höchstmögliche
Auslastung erreicht werden kann, ohne das viele Kunden verärgert werden.

#### **Testfälle**

Test mit 4 Kassen:
Keine verärgerten Kunden und sehr kurze Wartezeit, aber auch geringe Auslastung.

<img src="Images/4Kassen.png" alt="Image_4Kassen" width="500">

Test mit 2 Kassen:
Gute Auslastung, aber viele verärgerte Kunden und lange Wartezeit.

<img src="Images/2Kassen.png" alt="Image_2Kassen" width="500">

Test mit 3 Kassen:
Akzeptable Auslastung und sehr wenige verärgerte Kunden mit kurzer Wartezeit.

<img src="Images/3Kassen.png" alt="Image_3Kassen" width="500">

#### **Empfehlung**
Wenn Kassenanzahl konstant sein muss, dann sind 3 Kassen optimal, da sehr wenige Kunden
verärgert werden und eine höhere Auslastung als bei 4 Kassen erzielt wird. Sinvollerweise
sollten die Kassen natürlich geschlossen sein wenn auch der Supermarkt geschlossen ist,
nachdem die noch in der Schlange stehenden Kunden abgearbeitet sind.
Bei variabler Kassenanzahl, würden während den Stunde 0-4 2 Kassen ausreichen, da
die Auslastung nicht einmal 50 % erreicht. 