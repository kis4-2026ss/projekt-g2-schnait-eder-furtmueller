[![Review Assignment Due Date](https://classroom.github.com/assets/deadline-readme-button-22041afd0340ce965d47ae6ef1cefeee28c7c493a6346c4f15d667ab976d596c.svg)](https://classroom.github.com/a/9WKHkcR7)
# **SWJ3-Übungen - WS2025 - Übung 1**

## Diskrete Ereignissimulation (`src/des`)

Diskrete Ereignissimulation (DES) ist eine Methode zur Modellierung und Analyse
komplexer Systeme, bei der eine Abfolge von Ereignissen simuliert wird, die zu
bestimmten Zeitpunkten auftreten und den Zustand des Systems verändern. Anders
als bei kontinuierlichen Simulationen wird hier nicht jede Zeiteinheit
betrachtet, sondern nur die Zeitpunkte, an denen sich der Zustand des Systems
tatsächlich ändert. Durch Verfolgung des Zustands der simulierten Entitäten
ermöglicht diese Technik Einblicke in die zu erwartende Gesamtleistung des
Systems, das Erkennen von Engpässen und eine Abschätzung der
Ressourcenauslastung.

### Funktionsprinzip

Das Herzstück der DES ist die *Ereigniswarteschlange*, die alle geplanten
  zukünftigen Ereignisse enthält. Jedes Ereignis hat einen *Zeitstempel* und
  beschreibt eine Änderung im System (z. B. Kunde betritt supm.Supermarkt, Bedienung
  des Kunden beginnt, Kunde verlässt den supm.Supermarkt etc.). Die Simulation
  springt *direkt von einem Ereignis zum nächsten*, ohne die Zeit dazwischen zu
  berücksichtigen. Bei der Abarbeitung eines Ereignisses können *neue
  Ereignisse* erzeugt und in die Warteschlange eingefügt werden. Die Simulation
  endet, wenn ein *Endzeitpunkt* erreicht ist oder die Ereigniswarteschlange
  leer ist.

### Vorteile der DES

- *Effizienz:* Nur relevante Zeitpunkte werden berechnet, Zeit zwischen
  Ereignissen wird übersprungen.
- *Flexibilität:* Verschiedene Arten von Ereignissen können modelliert werden.
- *Erweiterbarkeit:* Neue Ereignistypen lassen sich einfach hinzufügen.

### Beispielhafte Event-Abfolge (supm.Supermarkt mit zwei Kassen)

|Zeit | Ereignis                | Aktionen                                              | Neue Events                           |
|-----|-------------------------|-------------------------------------------------------|---------------------------------------|
| 0.5 | Kunde 1 trifft ein      | Kunde 1 → Kassa 1, <br>Bedienung startet.             | Ende Bedienung Kunde 1 @ 3.5<br>Nächster Kunde @ 2.5 |
| 2.5 | Kunde 2 trifft ein      | Kunde 2 → Kassa 2, <br>Bedienung startet.             | Ende Bedienung Kunde 2 @ 4.0<br>Nächster Kunde @ 3.1 |
| 3.1 | Kunde 3 trifft ein      | Beide Kassen belegt <br>→ Warteschlange K1.           | Nächster Kunde @ 3.8                  |
| 3.5 | Bedienung Kunde 1 endet | Kunde 3 aus Warteschlange K1 <br>→ Bedienung startet. | Ende Bedienung Kunde 3 @ 5.3          |
| 3.8 | Kunde 4 trifft ein      | Beide Kassen belegt<br> → Warteschlange K1.           | Nächster Kunde @ 4.5                  |
| 4.0 | Bedienung Kunde 2 endet | Kassa 2 frei, keine Warteschlange.                    | —                                     |
| 4.5 | Kunde 5 trifft ein      | Kunde 5 → Kassa 2, <br>Bedienung startet.             | Ende Bedienung Kunde 5 @ 6.5          |
| 5.3 | Bedienung Kunde 3 endet | Kunde 4 aus Warteschlange K1<br> → Bedienung startet. | Ende Bedienung Kunde 4 @ 6.9          |
| 6.5 | Bedienung Kunde 5 endet | Kassa 2 frei, keine Wartenden.                        | —                                     |
| 6.9 | Bedienung Kunde 4 endet | Kassa 1 frei, keine Wartenden.                        | —                                     |

### Implementierung

Implementieren Sie ein Programm zur Simulation der Bedienung von Kunden an den
Kassen eines Supermarktes. Gehen Sie dazu in folgenden Schritten vor.

1. **Simulationsbibliothek**

   Konzipieren und implementieren Sie zunächst eine allgemein einsetzbare
   Simulationsbibliothek in Form von Java-Klassen und unter möglichst
   weitreichendem Einsatz von Java-Behälterklassen. Die richtige Wahl der
   Datenstruktur zur Verwaltung der Ereignisse ist hier von zentraler Bedeutung.
   Folgende Funktionalität muss mindestens verfügbar sein:

    * Zukünftige Ereignisse müssen für einen bestimmten Zeitpunkt geplant werden
      können und in einer effizienten Datenstruktur gehalten werden.

    * Es müssen verschiedene Arten von Ereignissen simuliert werden können und
      es muss einfach möglich sein, neue Ereignistypen hinzuzufügen.

    * Die Simulation muss schrittweise ausgeführt werden können. Es muss also z.
      B. eine Methode `step()` geben, die nur das nächste Ereignis abarbeitet.

    * Die Simulation muss bis zu einem bestimmten Zeitpunkt ausgeführt werden
      können. Es muss also z. B. eine Methode `run()` geben, welche die
      Ereigniswarteschlange abarbeitet, bis diese leer ist oder die
      Simulationszeit einen vorgegebenen Zeitpunkt überschreitet.

2. **Anwendungsszenario supm.Supermarkt**

    Simulieren Sie die Abläufe in einem *supm.Supermarkt* und berücksichtigen Sie dabei
    folgende Anforderungen:

    * Es gibt eine *feste Anzahl von Kassen*, an denen Kunden bedient werden. Die
      Anzahl der Kassen ist konfigurierbar.
    * Kunden betreten den supm.Supermarkt *zufällig*. Die Anzahl der Kunden, die in einer
      Zeitspanne den supm.Supermarkt betreten, ist Poisson-verteilt. Somit ist die Zeit
      zwischen zwei Ankünften exponential-verteilt.
    * Jeder Kunde hat eine *Servicezeit*, die *normalverteilt* ist.
    * Wenn keine Kassa frei ist, *reiht sich der Kunde bei der Kasse mit der
      kürzesten Warteschlange ein* und wartet darauf, bedient zu werden..
    * Ein Kunde *bricht den Kauf ab*, wenn die Wartezeit in der Warteschlange
      eine bestimmte Grenze überschreitet.
    * Sobald eine Kassa frei wird, wird der *nächste Kunde in der Warteschlange*
      bedient.
    * Speichern Sie die Simulationsparameter an einer zentralen Stelle in Ihrem
      Programm. Bisher sind folgende Parameter angefallen:
      - Anzahl der Kassen
      - Simulationsdauer in Minuten
      - Durchschnittliche Anzahl ankommender Kunden pro Zeiteinheit
      - Durchschnittliche Bedienzeit, Standardabweichung der Bedienzeit
      - Zeit, nach der Kunde abbricht (in Minuten)
    * Protokollieren Sie die Abläufe in der Simulation durch geeignete
      Konsolenausgaben (z. B. Kunde x kommt an, Kunde x reiht sich in Warteschlange von
      Kassa y ein etc.). Das Ablaufprotokoll muss aktiviert und deaktiviert werden
      können.

    *Hinweise:*
      * Normalverteilte Zufallszahlen (N(μ=0, σ=1)) lassen sich mit der Methode
        `Random.nextGaussian()` ermitteln.
      * Eine gleichverteilte Zufallszahl $u$ aus dem Interval $(0,1]$ kann mit
        $-\ln(u)/\lambda$ in eine exponentialverteilte Zufallszahl transformiert
        werden ($\lambda$ ist die durchschnittliche Anzahl von Ereignissen pro
        Zeiteinheit). Diese Zufallszahl gibt die Zeit bis zum Auftreten des
        nächsten Ereignisses an. 
 
3. *Statistische Auswertung*

    Die Simulation hat für den Anwender nur dann einen Wert, wenn Sie während eines
    Simulationslaufs statistische Daten mitführen. Folgende Kennzahlen sind zu
    ermitteln und am Ende der Simulation in übersichtlicher Form auszugeben:

    * Anzahl der insgesamt bedienten Kunden pro Kassa und insgesamt
    * Maximale Länge der Warteschlange pro Kassa 
    * Anzahl der Kunden, die ihren Einkauf abgebrochen haben
    * Durchschnittliche Wartezeit
    * Auslastung der Kassen: Hier ist eine Tabelle zu erstellen, aus welcher der
      Verlauf der Auslastung der Kassen ersichtlich ist. Die Granularität der
      auszugebenden Auslastungsintervalle muss konfigurierbar sein. Die
      Auslastungstabelle sollte in etwa so aussehen:
        ```text
        Interval          | Counter-1 | Counter-2 | Counter-3 |  Avg Util
        ------------------|-----------|-----------|-----------|----------
        [   0,0 -   60,0] |     89,1% |     49,6% |     28,4% |     55,7%
        [  60,0 -  120,0] |     75,0% |     37,6% |      0,0% |     37,5%
        [ 120,0 -  180,0] |     75,6% |     32,2% |     15,1% |     41,0%
        ...
        ```
 
4. **Profile**

    Bisher sind wir davon ausgegangen, dass über den gesamten
    Simulationszeitraum hinweg die Ankunftsrate der Kunden gleich bleibt. Um die
    Simulation realistischer zu gestalten, sollen *Ankunftsprofile* erstellt
    werden. Neben dem Ankunftsprofil mit einer gleichbleibenden Ankunftsrate
    soll es auch ein Profil geben, mit dem sich variierende Ankunftsraten
    abbilden lassen. Dazu wird eine Zeitperiode (z. B. ein Tag) in *n* gleiche
    Intervalle unterteilt (z. B. ein Tag in 6 Intervalle von 4 Stunden). Für
    jedes Intervall kann die durchschnittliche Anzahl ankommender Kunden
    angegeben werden. Es ist wichtig, dass die Kundenanzahl auch auf 0 gesetzt
    werden kann (supm.Supermarkt ist geschlossen). Nach Ablauf einer Periode
    wiederholen sich die Ankunftsraten, sodass beispielsweise mehrere
    aufeinanderfolgende Tage simuliert werden können.

    Auch diese Anforderung lässt sich mit den Konzepten der objektorientierten
    Programmierung besonders gut umsetzen. Streben Sie ein Design an, mit dem
    sich neue Ankunftsprofile einfach hinzfügen lassen. 

5. **Auswertung und Interpretation der Ergebnisse** 
 
    Führen Sie für folgendes Profil einen Simulationslauf durch: 
    * Kundenaufkommen pro Tag (Durchschnittswerte):
      - Stunde  0 –  4: 100,
      - Stunde  5 –  8: 220, 
      - Stunde  9 – 12: 150, 
      - Stunde 13 – 24:   0 
    * Bedienzeit: N(μ=3, σ=2)
    * Abbruch des Einkaufs: Nach 15 Minuten.
    * Simulationsdauer: 5 Tage.

    Interpretieren Sie Ihre Ergebnisse und überprüfen Sie in diesem Zuge auch
    deren Plausibilität. Geben Sie für den/die Betreiber*in des Supermarktes
    eine Empfehlung ab, wie viele Kassen er/sie benötigt und wie er/sie eine
    möglichst gute Auslastung der Kassen erreichen kann, ohne viele Kunden zu
    verärgern. Dokumentieren Sie Ihre Überlegungen.

### Allgemeine Anforderungen

* Erstellen Sie für alle Komponenten Ihres Systems eine *umfassende
  Unit-Test-Suite*. Gestalten Sie Ihr System so, dass die Komponenten für sich,
  unabhängig von anderen Komponenten getestet werden können.

* Achten Sie auf ein sauberes objektorientiertes Design.

* Versuchen Sie, durch Einsatz von geeigneten Klassen des Behälter-Frameworks von
  Java die Laufzeiteffizienz Ihres Programms zu optimieren (insbesondere die
  Ereigniswarteschlange und die Auslastungsstatistik).